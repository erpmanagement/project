<div class="col-md-4"></div>
		<div class="col-md-4">
			<?php
				require_once 'connect.php';
				$query = "SELECT * from info order by id desc";
			//		echo $query;
				$result =mysqli_query($con,$query);
				?>
				<table class="table table-striped table-bordered table-hover table-condensed">
				<tr>
					<th>#</th>
					<th>Name</th>
					<th>Designation</th>
					<th>Salary</th>
					<th>Actions</th>
				</tr>
				<?php
				$sum=0;
				while ($row = mysqli_fetch_row($result)){
					echo "<tr>
							<td>$row[0]</td>
							<td>$row[1]</td>
							<td>$row[2]</td>
							<td>$row[3]</td>
							<td>Nothing4Now</td>
					</tr>";
					$sum=$sum+$row[3];
				}
				echo "<tr>
				<td></td>
				<td></td>
				<td>Total:</td>
				<td>$sum</td>
				</tr>";

				?>
			</table>
		</div>
		<div class="col-md-4"></div>
