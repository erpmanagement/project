
<?php
	$host="10.9.2.82";
	$user="mca5";
	$pass="123";
	$dbname="demo";
	$con = mysqli_connect($host,$user,$pass,$dbname);
	
	if(mysqli_connect_error()){
		echo "Connection Error: ".mysqli_connect_error();
	}
?>
