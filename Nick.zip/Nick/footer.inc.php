	<!--Footer Starts-->
	<hr>
	<h5 align="center"><strong>Copyrighted by: Nikunj Katrodiya &reg;</strong></h5>
	<h5 align="center">Site was last updated on  : 11/07/2016 Time: 10:07 PM IST</h5>
	
	<!-- jQuery library -->
	<script src="./js/jquery-3.0.0.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="./bootstrap-3.3.6/js/bootstrap.min.js"></script>
	<!--Footer Ends-->
