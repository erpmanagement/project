<div class="col-md-4"></div>
		<div class="col-md-4">
			<?php
				require_once 'connect.php';
				$query = "SELECT * from info order by id desc";
			//		echo $query;
				$result =mysqli_query($con,$query);
				?>
				<div class="col-md-10"></div>
				<div class="col-md-2"><button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-th-list"></span> &nbsp; Create</button></div>
				
				<table class="table table-striped table-bordered table-hover table-condensed">
				<tr>
					<th>#</th>
					<th>Name</th>
					<th>Designation</th>
					<th>Salary</th>
					<th colspan=2>Actions</th>
				</tr>
				<?php
				$sum=0;
				while ($row = mysqli_fetch_row($result)){
					echo "<tr>
							<td>$row[0]</td>
							<td>$row[1]</td>
							<td>$row[2]</td>
							<td>$row[3]</td>
						
							<td><a href='edit.php?id=$row[0]' class='btn btn-primary'><span class='glyphicon glyphicon-edit'></span> &nbsp;Edit</a> </td>
							<td><a href='delete.php' class='btn btn-danger'><span class='glyphicon glyphicon-remove-sign'></span> &nbsp;Delete</a> 
							</td>
					</tr>";
					
					$sum=$sum+$row[3];
				}
				echo "<tr>
				<td></td>
				<td></td>
				<td>Total:</td>
				<td>$sum</td>
				</tr>";

				?>
			</table>
		</div>
		<div class="col-md-4"></div>
