<html>
<head>
<?php
	session_start();
	require_once 'title.inc.php';
?>
</head>
<body>
	<?php 
		require_once 'head.inc.php';
	?>
	<div class="container">
		<?php
			require_once 'menu.inc.php';
		?>
		<div class="col-md-12">
		
		</div>
		<h3> Please Sign In ...</h3>
		<form action="" method="POST" class="form-horizontal" role="form">
			<div class="form-group">
				<label class="control-label col-sm-2">Username: </label>
				<div class="col-sm-10">
					<input type="text" name="nm" />
				</div>
			</div>
			<div class="form-group">
			<label class="control-label col-sm-2">Password: </label>
			<div class="col-sm-10">
				<input type="text" name="pwd" />
			</div>
			</div>
			<div class="form-group">
			<div class="col-sm-offset-2 col-sm-10">
				<button type="submit" name="submit"  class="btn btn-primary"><span class=" glyphicon glyphicon-random"></span>&nbsp; Submit Me!</button>
				<button type="reset" name="reset"  class="btn btn-default">Reset</button>
			</div>
			</div>
		</form>
		<?php 
			//require_once 'display.php';
		?>
	</div>
	<?php 
		require_once 'footer.inc.php';
	?>
</body>
</html>

<?php
 require_once 'connect.php';
 if(isset($_POST['submit'])){
 	$nm  = $_REQUEST['nm'];
 	$pwd = $_REQUEST['pwd'];
 	$query="SELECT * FROM userinfo where username='$nm' and password=sha1('$pwd')";
 	$result=mysqli_query($con,$query);
	$row = mysqli_num_rows($result);	
	$val =mysqli_fetch_row($result);
 	if($row == 1){
 		echo "Login Successful";
 			$_SESSION['id']=$val[0];
			$_SESSION['user']=$val[1];
			$_SESSION['tp']=$val[3];
			$_SESSION['status']=$val[4];
			echo $val[0]."</br>";
			echo $val[1]."</br>";
			echo $val[3]."</br>";
			echo $val[4]."</br>";
			$query="UPDATE userinfo SET lastlogin = CURRENT_TIMESTAMP WHERE id = $_SESSION[id]";
			mysqli_query($con,$query);
 	}
 	else{
 		echo "Login is not successful";
 	}
 }
?>
