<html>
<head>
<?php
	require_once 'title.inc.php';
?>
</head>
<body>
	<?php 
		require_once 'head.inc.php';
	?>
	<div class="container">
		<?php
			require_once 'menu.inc.php';
		?>
		<div class="col-md-12">
		This is my Demo Webiste do visit again.
		</div>
		<?php 
			require_once 'display.php';
		?>
	</div>
	<?php 
		require_once 'footer.inc.php';
	?>
</body>
</html>
