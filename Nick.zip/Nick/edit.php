<html>
<head>
<?php
	require_once 'title.inc.php';
?>
</head>
<body>
	<?php 
		require_once 'head.inc.php';
		require_once 'connect.php';
	?>
	<div class="container">
		<?php
			require_once 'menu.inc.php';
			if($_GET){
				$id=$_GET['id'];
				$query = "SELECT * FROM info where id=$id";
				$result=mysqli_query($con, $query);
				$row=mysqli_fetch_row($result);
				
			}
		?>		
		
			<form action="" method="post">
			Name: <input type="text" name="nm" value="<? echo $row[1]; ?>">
			Designation: <input type="text" name="desig" value="<?php echo $row[2]; ?>">
			Salary: <input type="text" name="sal" value="<?php echo $row[3]; ?>">
			<button type="submit" class="btn btn-default">Submit Me!</button>
			<button type="reset" class="btn btn-default">Reset!</button>
			</form>


			</div>
				<?php 
					if($_POST){
						$nm=$_POST['nm'];
						$desig=$_POST['desig'];
						$sal=$_POST['sal'];
						$query="UPDATE info SET name = '$nm', desig='$desig',salary='$sal' WHERE id ='$id' ";
						$result=mysqli_query($con,$query);
						if($result){
							echo "<script>window.location.href='index.php';</script>";
						}
						
					}
					require_once 'footer.inc.php';
				?>
</body>
</html>
