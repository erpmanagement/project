<html>
<head>
<?php
	require_once '../title.inc.php';
?>
</head>
<body>

	<?php 
		require_once '../head.inc.php';
	?>
	<div class="container">
		<pre>
		<?php
			print_r($_FILES);
		?>
		</pre>
	</div>
	<?php 
		require_once '../footer.inc.php';
	?>
</body>

</html>
