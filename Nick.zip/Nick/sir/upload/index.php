<html>
<head>
<?php
	require_once '../title.inc.php';
?>
</head>
<body>

	<?php 
		require_once '../head.inc.php';
	?>
	<div class="container">
		<?php
			require_once '../menu.inc.php';
		?>
		<div class="row>
			<div class="col-lg-12">
				<div class="form-group">
					<form class="well" action="upload.php" method="post" enctype="multipart/form-data" name="img">
						<label for="file">Select file to upload</label>
						<input type="file" name="file">
						<p class="help-block">Only jpeg, jpg, gif,png or pdf file with maximum size 1 MB is allowed </p>
						<input type="submit" value="Upload me!" class"btn btn-primary"/>		
				</div>	
				
			</form>
			</div>
		</div>
	</div>
	<?php 
		require_once '../footer.inc.php';
	?>
</body>

</html>
