
<?php
	$host="localhost";
	$user="root";
	$pass="";
	$dbname="demo";
	$con = mysqli_connect($host,$user,$pass,$dbname);
	
	if(mysqli_connect_error()){
		echo "Connection Error: ".mysqli_connect_error();
	}
?>
