<html>
<head>
<?php
	require_once 'title.inc.php';
?>
</head>
<body>
<?php 
		require_once 'head.inc.php';
		require_once 'connect.php';
		if($_GET){
			$id=$_GET['id'];
			$query="SELECT * FROM info where id=$id";
			$result=mysqli_query($con,$query);
			$row=mysqli_fetch_row($result);
		
		}
		if($_POST){
			$nm=$_POST['nm'];
			$desig=$_POST['desig'];
			$sal=$_POST['sal'];
			$query="update info set name='$nm', desig='$desig', salary='$sal' where id=$id";
			//echo $query;
			$result=mysqli_query($con,$query);
			if($result){
				echo "Updation is successful";
				echo "<script>window.location.href='index.php';</script>";
			}
			else{
				echo "Some problem exists: ".mysqli_error();
			}
		}
	?>
	<div class="container">
		<?php
			require_once 'menu.inc.php';
		?>
		<form action="" method="post">
		<label>Name:</label> <input type="text" name="nm" value="<?php echo $row[1]; ?>"/>
		<label>Designation:</label> <input type="text" name="desig" value="<?php echo $row[2]; ?>"/>
		<label>Salary:</label> <input type="text" name="sal" value="<?php echo $row[3]; ?>"/>
		<button class="btn btn-primary" name="submit" type="submit"> Edit</button>
		<button class="btn btn-primary" name="reset" type="reset"> Reset</button>
		</form>
	</div>
	<?php 
		require_once 'footer.inc.php';
	?>

</body>
</html>
