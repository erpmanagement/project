 <!DOCTYPE html>
<html>
<head>
 
<script src="http://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script> 
<script>
var myCenter=new google.maps.LatLng(22.28130,70.76703);
function initialize() {
  var mapProp = {
    center:new google.maps.LatLng(22.28130,70.76703),
    zoom:15,
    mapTypeId:google.maps.MapTypeId.ROADMAP
  };

  var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
   var marker = new google.maps.Marker({
  		position:myCenter,
		animation:google.maps.Animation.BOUNCE,
		icon: 'icon.png'
  });
  marker.setMap(map);
}
google.maps.event.addDomListener(window, 'load', initialize);
</script>
</head>

<body>
<div id="googleMap" style="width:500px;height:380px;"></div>
</body>

</html> 