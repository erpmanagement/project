<?php
	require_once 'gmail.php';
	if($_POST){
		$to=$_POST['to'];
		$sub=$_POST['sub'];
		$body=$_POST['body'];
		$name=$_POST['name'];
		//echo "$to,$body,$sub,$name";
		
		sendme($to,$body,$sub,$name);


	}

?>
