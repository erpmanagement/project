<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	
	<?php
		require_once '../title.inc.php';
	?>
</head>
<body>
<?php 
		require_once '../head.inc.php';
	?>
	<div class="container">
	<?php
			require_once '../menu.inc.php';
		?>
	
		<div class="container-fluid">
			<div class="row">
				<form action="sendmail.php" method="post">
					<h3>Sending Email</h3>
					<label for="name">Name:</label>
					<div class="form-group">
						<input type="text" name="name" />
					</div>
					<label>To:</label>		
					<div class="form-group">
						<input type="email" name="to" />
					</div>
					<label>Subject:</label>
					<div class="form-group">
						<input type="text" name="sub" />
					</div>
					<label>Body:</label>
					<div class="form-group">
						<textarea name="body"></textarea>
						<input type="submit" name="submit" value="Send Mail"/>
					</div>
				</form>
			</div>
		</div>	
	</div>
	<?php 
		require_once '../footer.inc.php';
	?>
</body>
</html>	